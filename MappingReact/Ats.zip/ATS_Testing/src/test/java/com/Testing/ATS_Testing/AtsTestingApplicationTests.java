package com.Testing.ATS_Testing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtsTestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
