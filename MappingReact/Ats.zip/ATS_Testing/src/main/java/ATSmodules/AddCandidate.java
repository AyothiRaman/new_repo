package ATSmodules;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class AddCandidate {

	WebDriver driver;

	public AddCandidate(WebDriver driver) {
		super();
		this.driver = driver;
	}

	@FindBy(how = How.XPATH, using = "//*[@id=\"Candidate\"]/button/span/div/img")
	@CacheLookup
	WebElement candiateSideBar;

	@FindBy(how = How.XPATH, using = "//*[@id=\"id__40\"]")
	@CacheLookup
	WebElement addCandidateButton;

	@FindBy(how = How.XPATH, using = "	//*[@id=\"Dropdown57-option\"]")
	@CacheLookup
	WebElement status;

	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField59\"]")
	@CacheLookup
	WebElement ExpectCTC;

	@FindBy(how = How.XPATH, using = "//*[@id=\"Dropdown58-option\"]")
	@CacheLookup
	WebElement noticePeriod;

	@FindBy(how = How.XPATH, using = "//*[@id=\"Dropdown64-option\"]")
	@CacheLookup
	WebElement modeOfHire;
	
	               //BASIC INFORMATION

	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField65\"]")
	@CacheLookup
	WebElement firstName;

	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField70\"]")
	@CacheLookup
	WebElement lastName;

	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField75\"]")
	@CacheLookup
	WebElement emailID;

	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField80\"]")
	@CacheLookup
	WebElement mobileNumber;

	@FindBy(how = How.XPATH, using = "//*[@id=\"Dropdown85-option\"]")
	@CacheLookup
	WebElement gender;

	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField86\"]")
	@CacheLookup
	WebElement state;

	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField91\"]")
	@CacheLookup
	WebElement city;

	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField96\"]")
	@CacheLookup
	WebElement pincode;
	
	                  // EMPLOYMENT DETAILS

	@FindBy(how = How.XPATH, using = "//*[@id=\"ModalFocusTrapZone31\"]/div[2]/div[2]/div[2]/div[2]/div[2]/div/table/tbody/tr/td[1]/div/div/input")
	@CacheLookup
	WebElement setCurrentCompany;

	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField101\"]")
	@CacheLookup
	WebElement companyName;

	@FindBy(how = How.XPATH, using = "//*[@id=\"DatePicker106-label\"]/span")
	@CacheLookup
	WebElement startDate;

	@FindBy(how = How.XPATH, using = "//*[@id=\"DatePicker113-label\"]/span")
	@CacheLookup
	WebElement endDate;

	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField120\"]")
	@CacheLookup
	WebElement jobRole;

	@FindBy(how = How.XPATH, using = "//*[@id=\"Dropdown125-option\"]")
	@CacheLookup
	WebElement workModel;

	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField126\"]")
	@CacheLookup
	WebElement Ectc;

	@FindBy(how = How.XPATH, using = "//*[@id=\"Dropdown125-option\"]")
	@CacheLookup
	WebElement Etype;


	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField132\"]")
	@CacheLookup
	WebElement iType;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField137\"]")
	@CacheLookup
	WebElement c2hPayroll;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField142\"]")
	@CacheLookup
	WebElement jobSkill;
	
	@FindBy(how = How.XPATH, using = "	//*[@id=\"ModalFocusTrapZone50\"]/div[2]/div[2]/div[2]/div[2]/div[1]/div[2]")
	@CacheLookup
	WebElement addEmploymentDetails;
	
	@FindBy(how = How.XPATH, using = "	//*[@id=\"ModalFocusTrapZone50\"]/div[2]/div[2]/div[2]/div[2]/div[2]/div/table/tbody/tr/td[12]/div/i")
	@CacheLookup
	WebElement deleteEmploymentDetails;

	                 // PREFERENCES
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField147\"]")
	@CacheLookup
	WebElement currentLocation;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"Toggle152\"]")
	@CacheLookup
	WebElement relocate;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField153\"]")
	@CacheLookup
	WebElement preferredLocation;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField158\"]")
	@CacheLookup
	WebElement skillSet;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField163\"]")
	@CacheLookup
	WebElement rExperienceYears;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField168\"]")
	@CacheLookup
	WebElement  rExperienceMonths;
	

	@FindBy(how = How.XPATH, using = "//*[@id=\"ModalFocusTrapZone50\"]/div[2]/div[2]/div[2]/div[2]/div[3]/div[2]/div[1]/div[2]")
	@CacheLookup
	WebElement  addPreferences;
	

	@FindBy(how = How.XPATH, using = "//*[@id=\"ModalFocusTrapZone50\"]/div[2]/div[2]/div[2]/div[2]/div[3]/div[2]/div[3]/div[2]/div[3]/div/i")
	@CacheLookup
	WebElement  deletePreferences;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void addCandidatePress(String ctc, String fName, String lName, String email, String mobile, String sta,String cit, String pin, 
			                            String Cname, String jRole, String employmentCTC,String indType,String cPayroll,String jSkill,
			                                 String currLocation,String pLocation,String sSet,String eYears,String eMonths) {

		try {
			candiateSideBar.click();

			addCandidateButton.click();

			// status
			// status.click();

			// Expected CTC
			// ExpectCTC.sendKeys(ctc);

			// Notice Period
			// noticePeriod.click();

			// Mode Of Hire
			// modeOfHire.click();

			// First Name
			firstName.sendKeys(fName);

			// Last Name
			lastName.sendKeys(lName);

			// Email ID
			emailID.sendKeys(email);

			// MobileNumber
			mobileNumber.sendKeys(mobile);

			// Gender
			// gender.click();

			// State
			state.sendKeys(sta);

			// City
			city.sendKeys(cit);

			// PinCode
			pincode.sendKeys(pin);

			// setCurrentCompany.click();

			// company Name
			companyName.sendKeys(Cname);

			// start Date
			startDate.click();

			// End Date
			endDate.click();

			// Job role
			jobRole.sendKeys(jRole);

			// Work Model
			workModel.click();

			// Employment CTC

			Ectc.sendKeys(employmentCTC);

			// Employment Type
			Etype.click();
			
			//Industry Type
			iType.sendKeys(indType);
			
			//payroll
			c2hPayroll.sendKeys(cPayroll);
			
			//job Skill
			jobSkill.sendKeys(jSkill);
			
			addEmploymentDetails.click();
			
			Thread.sleep(4000);
			
			deleteEmploymentDetails.click();
			
			//Current Location
			currentLocation.sendKeys(currLocation);
			
			relocate.click();
			
			preferredLocation.sendKeys(pLocation);
			
			skillSet.sendKeys(sSet);
			
		rExperienceYears.sendKeys(eYears);
		rExperienceMonths.sendKeys(eMonths);
		
		addPreferences.click();
		Thread.sleep(3000);
		deletePreferences.click();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
