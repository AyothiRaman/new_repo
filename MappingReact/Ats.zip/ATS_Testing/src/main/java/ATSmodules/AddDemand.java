package ATSmodules;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class AddDemand {

	WebDriver driver;

	public AddDemand(WebDriver driver) {
		super();
		this.driver = driver;
	}

	@FindBy(how = How.XPATH, using = "//*[@id=\"demand\"]/button/span/div/img")
	@CacheLookup
	WebElement demandImageClick;

//	@FindBy(how = How.XPATH, using = "//*[@id=\"demand\"]/div/button[1]/span/div/div")
//	@CacheLookup
//	WebElement manageDemamnd;
	//*[@id=\"fluent-default-layer-host\"]/div/div/div/div/div/button[2]/span/div/div
	//*[@id="demand"]/div/button[1]/span/div/div

	@FindBy(how = How.XPATH, using = "//*[@id=\"id__40\"]")
	@CacheLookup
	WebElement addDemandButton;

	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField57\"]")
	@CacheLookup
	WebElement jobTitle;
	
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"id__62\"]")
	@CacheLookup
	WebElement saveAndClose;

	@FindBy(how = How.XPATH, using = "//*[@id=\"personaId\"]/div/div[1]")
	@CacheLookup
	WebElement unAssigned;

	@FindBy(how = How.XPATH, using = "//*[@id=\"Dropdown65-option\"]")
	@CacheLookup
	WebElement status;

	@FindBy(how = How.XPATH, using = "//*[@id=\"Dropdown71-option\"]")
	@CacheLookup
	WebElement priority;

	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField66\"]")
	@CacheLookup
	WebElement noOfPositions;

	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField72\"]")
	@CacheLookup
	WebElement client;

//	@FindBy(how = How.XPATH, using = "//*[@id=\"rdw-wrapper-1231\"]/div[2]")
//	@CacheLookup
//	WebElement jobDescription;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField90\"]")
	@CacheLookup
	WebElement vendor;
	
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField95\"]")
	@CacheLookup
	WebElement poc;
	
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField100\"]")
	@CacheLookup
	WebElement jobId;
	
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField108\"]")
	@CacheLookup
	WebElement skillSet;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField113\"]")
	@CacheLookup
	WebElement RskillYears;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"TextField118\"]")
	@CacheLookup
	WebElement RskillMonths;
	
	
	
//	@FindBy(how = How.XPATH, using = "//*[@id=\"DatePicker77-label\"]/span")
//	@CacheLookup
//	List<WebElement> datePicker;
//	
//
//	@FindBy(how = How.XPATH, using = "//*[@id=\"DatePicker-Callout78\"]/div/div/div[2]/div[2]/div[2]/table/tbody/tr[4]/td[7]/button/span")
//	@CacheLookup
//	List<WebElement> days;
	
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"Dropdown84-option\"]")
	@CacheLookup
	WebElement minExperienceMonths;
	
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"Dropdown85-option\"]")
	@CacheLookup
	WebElement minExperienceYears;
	

	@FindBy(how = How.XPATH, using = "//*[@id=\"Dropdown87-option\"]")
	@CacheLookup
	WebElement maxExperienceMonths;
	

	@FindBy(how = How.XPATH, using = "//*[@id=\"Dropdown88-option\"]")
	@CacheLookup
	WebElement maxExperienceYears;
	
//
//	@FindBy(how = How.XPATH, using = "//*[@id=\"Dropdown89\"]")
//	@CacheLookup
//	WebElement modeOfHire;
	
	
	//*[@id=\"Dropdown89-option\"]
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"rdw-wrapper-8205\"]/div[2]/div/div[2]/div/div/div/div")
	@CacheLookup
	WebElement addDescription;
	
	

	public void addDemandPress(String jobT, String position, 
			String cli, String jobDes ,String vend,String pOfContact,String job,String sSet,String rMonth,String rYear,String description
			         ) {
		
		try {

			demandImageClick.click();

			//manageDemamnd.click();
//			Select demand = new Select(demandImageClick);
//			demand.selectByIndex(0);
//			
			addDemandButton.click();

			// job title
			jobTitle.sendKeys(jobT);
			//Thread.sleep(3000);
			
			saveAndClose.click();

		

			//unAssigned
			
			
//			unAssigned.click();
//			
//			Select unAs = new Select(unAssigned);
//			unAs.selectByIndex(1);
//			
			


			// status
		//	status.click();
			
			// priority
//			priority.click();
//			
//			// no of positions
			noOfPositions.sendKeys(position);;
			//Thread.sleep(4000);

			// client
			client.sendKeys(cli);
			//Thread.sleep(1000);

			// job Description
//			jobDescription.click();
//			jobDescription.sendKeys(jobDes);
			
			vendor.sendKeys(vend);
			
			poc.sendKeys(pOfContact);
			
			
			jobId.sendKeys(job);
			
			skillSet.sendKeys(sSet);
			
			RskillYears.sendKeys(rYear);
			RskillMonths.sendKeys(rMonth);
			
			//min Experience
		//	minExperienceMonths.click();
		//	minExperienceYears.click();
			
			//max Experience
		//	maxExperienceMonths.click();
		//	maxExperienceYears.click();
			
			//modeOfHire.click();
			
//			Select mod = new Select((WebElement) By.xpath("//*[@id=\"Dropdown89\"])"));
//			mod.selectByIndex(1);
			
			addDescription.sendKeys(description);
			
			
			
			
			
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

}
