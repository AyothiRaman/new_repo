package com.Testing.ATS_Testing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtsTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtsTestingApplication.class, args);
	}

}
