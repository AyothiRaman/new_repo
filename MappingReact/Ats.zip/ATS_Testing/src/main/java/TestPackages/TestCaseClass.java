package TestPackages;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import ATSmodules.AddCandidate;
import ATSmodules.AddDemand;
import ATSmodules.LoginPage;
import BrowserDetails.BrowserFactory;
import BrowserDetails.ScreenShot;

public class TestCaseClass extends HelperClass {

	public TestCaseClass() {

	}

	@Test
	public void returnResults() {

		try {
			System.out.println("ATS Page Starting");

			driver.get("https://sight-spectrum-ats.vercel.app/login");

			LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);

			loginPage.loginWordPress("testing@128.com", "HELLO123");
			
			
			
//			AddDemand demand = PageFactory.initElements(driver, AddDemand.class);
//			demand.addDemandPress("SQL", "23","client","jackjhjhjhjh","vend","poc10","jobId10","skill","1years","2months","hello");
			
			AddCandidate candidate = PageFactory.initElements(driver, AddCandidate.class);
			candidate.addCandidatePress("21000","john","wick","abc@gmail.com","1234567890","bnglr","hubli","123456",
					                         "spectrum","developer","300000","IT","24lpa","sql",
					                                "banglore","andhra","java, python","2","3");

			String capture = System.getProperty("user.dir") + "\\" + "ScreenShots\\Details"
					+ ScreenShot.getDateTimeStamp() + ".png";
			
			
			try {
				ScreenShot.getScreenShot(BrowserFactory.getDriver(), capture);
			}catch (Exception e) {
				e.printStackTrace();
			}

			

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
